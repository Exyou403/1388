import timeit
import os


class FileDuplicateRemover:
    def __init__(self, filename):
        self.filename = filename
        self.overwrite_mode = True

    def f7(self, seq):
        seen = set()
        seen_add = seen.add
        return [x for x in seq if not (x in seen or seen_add(x))]

    def convert_size(self, size):
        if size >= 1024:
            size /= 1024
            unit = "KB"
            if size >= 1024:
                size /= 1024
                unit = "MB"
            return "%.2f %s" % (size, unit)
        else:
            return "%.2f bytes" % size

    def remove_duplicates(self):
        print("[+] Original File Size: %s" % self.convert_size(os.path.getsize(self.filename)))

        start_time = timeit.default_timer()
        with open(self.filename, encoding="utf-8", errors="ignore") as file:
            content = [line.replace('\n', '') for line in file.readlines()]
        org_len = len(content)

        result = self.f7(content)
        stop_time = timeit.default_timer()
        duration = "%.5f seconds" % (stop_time - start_time)
        result_len = len(result)

        if org_len != result_len:
            print("[+] Processed: [%s] Lines in %s" % (org_len, duration))
            print("[+] <%s> duplicates found" % "{:,}".format(org_len - result_len))

            if self.overwrite_mode:
                new_filename = self.filename
            else:
                new_filename = "%s-no-dup.txt" % self.filename.replace('.txt', '')

            with open(new_filename, 'w') as new_file:
                for line in result:
                    new_file.write(line + '\n')

            print("[+] Saved as %s" % new_filename)
            print("[+] New File Size: %s" % self.convert_size(os.path.getsize(new_filename)))
        else:
            print("[+] Processed: [%s] Lines in %s" % (org_len, duration))
            print("[+] No duplicates found")